﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adopt_a_Dolphin
{
    internal class Dolphin
    {
        private List<Dolphin> Dolphins;
        private Player player = new Player();
        //Dolphin types
        //Titan - Bronze amulet and the sparkling water
        //Abson
        //
        //
        //

        //
        //

        //


    }
}
