﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adopt_a_Dolphin
{
    public class Dolphin
    {
        public string Name;
        public int age;
        public Dolphin(string name, int age)
        {
            this.Name = name;
            this.age = age;

        }

    }
}
