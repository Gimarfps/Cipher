﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adopt_a_Dolphin
{
    public class Player
    {
        public string Name = "";
        public List<Equips> Inventory = new List<Equips>();
        public List<Dolphin> AdoptedDolphins = new List<Dolphin>();

        public void AdoptnewDolphin(string name, int age) 
        {
            AdoptedDolphins.Add(new Dolphin(name, age));


        }
        public Player() { Inventory.Add(new Equips()); }
        
    }
}
