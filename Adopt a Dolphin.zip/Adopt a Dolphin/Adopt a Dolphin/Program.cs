﻿using System;

namespace Adopt_a_Dolphin
{
    public class Program
    {
        static Game game = new Game();
        static void Main(string[] args)
        {
            game.Start();
        }
    }
}