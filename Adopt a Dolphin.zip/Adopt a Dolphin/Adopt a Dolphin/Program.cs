﻿namespace Adopt_a_Dolphin
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}