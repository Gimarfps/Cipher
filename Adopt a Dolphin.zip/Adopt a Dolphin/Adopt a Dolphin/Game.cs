﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adopt_a_Dolphin
{
    public class Game
    {
        public string input; public Player player1 = new Player();
        public void Start() {
            Gameloop();
        }
        public bool Gameloop() 
        {
            Console.WriteLine("Enter Name!");
            input = Console.ReadLine();

            player1.Name = input;

            Console.WriteLine("Enter new dolphin name");
            input = Console.ReadLine();

            string Name = input;

            Console.WriteLine("Enter new dolphin age");

            input = Console.ReadLine();

            int age = Int32.Parse(input);
            player1.AdoptnewDolphin(Name, age);
            
            Console.WriteLine("You adopted a dolphin named " + player1.AdoptedDolphins[0].Name);

            return false; 
            

        }

    }
}
