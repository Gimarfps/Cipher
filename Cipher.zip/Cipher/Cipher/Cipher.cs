﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cipher
{
    public class Cipher
    {
        public string alphabet = "abcdefghijklmnopqrstuvwxyz";
        public string Key = "qwertyuiopasdfghjklzxcvbnm";
        public string incrypt(string input)
        {
            string output = "";
           foreach(char c in input)
            {
                for (int i = 0;i < 26;i++)
                {
                    if (c == alphabet[i])
                    {
                        output += Key[i];
                        break;
                    }
                }
            }

            return output;
        }

        public string decrypt(string input)
        {
            string output = "";
            foreach(char c in input)
            {
                for(int i = 0;i < 26;i++)
                {
                    if (c == Key[i])
                    {
                        output += alphabet[i];
                        break;
                    }
                }
            }


            return output;
        }
    }
}
