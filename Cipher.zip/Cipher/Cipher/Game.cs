﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Cipher
{
    public class Game
    {
        public string input;
        public Cipher cipher = new Cipher();
        public void Start()
        {
            //Welcome to Cipher.exe
            Console.WriteLine("Press E to incrypt Press D to decrypt");
            input = Console.ReadLine();
            if (input == "e")
            {
                Console.WriteLine("Enter your message to incrypt");
                input = Console.ReadLine();
                Console.WriteLine(cipher.incrypt(input));
            }
            else
            {
                Console.WriteLine("Enter incrypted message");
                input = Console.ReadLine();
                Console.WriteLine(cipher.decrypt(input));
            }
        }

    }
}
